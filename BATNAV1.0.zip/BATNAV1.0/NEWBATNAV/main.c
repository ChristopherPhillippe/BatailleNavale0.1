/*
 * Phillippe Jauregui
 * Bataille Navale, version 0.1
 * 11.03.2022
 */

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <conio.h>
#include <windows.h>
#include <dos.h>
#include <dir.h>


//Ce partie m'aide à afficher les caractères
#define STLC 218 // ┌, Single Top Left Corner
#define STRC 191 // ┐, Single Top Right Corner
#define SBLC 192 // └, Single Bottom Left Corner
#define SBRC 217 // ┘, Single Bottom Right Corner
#define SVSB 179 // │, Single Vertical Simple Border
#define SVRB 180 // ┤, Single Vertical Right Border
#define SVLB 195 // ├, Single Vertical Left Border
#define SHSB 196 // ─, Single Horizontal Simple Border
#define SHBB 193 // ┴, Single Horizontal Bottom Border
#define SHTB 194 // ┬, Single Horizontal Top Border
#define SC   197 // ┼, Single Center
#define DTLC 201 // ╔, Double Top Left Corner
#define DTRC 187 // ╗, Double Top Right Corner
#define DBLC 200 // ╚, Double Bottom Left Corner
#define DBRC 188 // ╝, Double Bottom Right Corner
#define DVSB 186 // ║, Double Vertical Simple Border
#define DVRB 185 // ╣, Double Vertical Right Border
#define DVLB 204 // ╠, Double Vertical Left Border
#define DHSB 205 // ═, Double Horizontal Simple Border
#define DHBB 202 // ╩, Double Horizontal Bottom Border
#define DHTB 203 // ╦, Double Horizontal Top Border
#define DC   206 // ╬, Double Center

void startBoard(int board[][9])
{

    int line, column;
    for(line=0 ; line < 9 ; line++ )
        for(column=0 ; column < 9 ; column++ )      //Ce partie change le valeur de chaque boîte à zero, pour que toute est vide
            board[line][column]=-1;
}

void showBoard(int board[][9])
{

    int line, column;


    //Tout les %c la sont pour afficher le grille
    printf("\n%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c\n", STLC, SHSB, SHSB, SHSB, SHSB, SHSB, SHTB, SHSB, SHSB, SHSB, SHSB, SHSB, SHTB, SHSB, SHSB, SHSB, SHSB, SHSB, SHTB, SHSB, SHSB, SHSB, SHSB, SHSB, SHTB, SHSB, SHSB, SHSB, SHSB, SHSB, SHTB, SHSB, SHSB, SHSB, SHSB, SHSB, SHTB, SHSB, SHSB, SHSB, SHSB, SHSB, SHTB, SHSB, SHSB, SHSB, SHSB, SHSB, SHTB, SHSB, SHSB, SHSB, SHSB, SHSB, SHTB, SHSB, SHSB, SHSB, SHSB, SHSB,STRC);
    printf("%c     %c  1  %c  2  %c  3  %c  4  %c  5  %c  6  %c  7  %c  8  %c  9  %c\n", SVSB, SVSB, SVSB, SVSB, SVSB, SVSB, SVSB, SVSB, SVSB, SVSB, SVSB);
    printf("%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c", SVLB, SHSB, SHSB, SHSB, SHSB, SHSB, SC, SHSB, SHSB, SHSB, SHSB, SHSB, SC, SHSB, SHSB, SHSB, SHSB, SHSB, SC, SHSB, SHSB, SHSB, SHSB, SHSB, SC, SHSB, SHSB, SHSB, SHSB, SHSB, SC, SHSB, SHSB, SHSB, SHSB, SHSB, SC, SHSB, SHSB, SHSB, SHSB, SHSB, SC, SHSB, SHSB, SHSB, SHSB, SHSB, SC, SHSB, SHSB, SHSB, SHSB, SHSB, SC, SHSB, SHSB, SHSB, SHSB, SHSB, SVRB);
    printf("\n");

    for(line=0 ; line < 8 ; line++ ){
        printf("%c  %d  %c", SVSB, line+1, SVSB);
        for(column=0 ; column < 9 ; column++ ){
            if(board[line][column]==-1){
                printf("     %c", SVSB);
            }else if(board[line][column]==0){               //Toute ça affiche la grille et les caractères pour voir ton score
                printf("  O  %c", SVSB);
            }else if(board[line][column]==1){
                printf("  X  %c", SVSB);
            }

        }
        printf("\n%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c\n", SVLB, SHSB, SHSB, SHSB, SHSB, SHSB, SC, SHSB, SHSB, SHSB, SHSB, SHSB, SC, SHSB, SHSB, SHSB, SHSB, SHSB, SC, SHSB, SHSB, SHSB, SHSB, SHSB, SC, SHSB, SHSB, SHSB, SHSB, SHSB, SC, SHSB, SHSB, SHSB, SHSB, SHSB, SC, SHSB, SHSB, SHSB, SHSB, SHSB, SC, SHSB, SHSB, SHSB, SHSB, SHSB, SC, SHSB, SHSB, SHSB, SHSB, SHSB, SC, SHSB, SHSB, SHSB, SHSB, SHSB, SVRB);
    }
    //Ce partie affiche le dernier ligne
    printf("%c  9  %c", SVSB, SVSB);
    for(column=0 ; column < 9 ; column++ ){
        if(board[line][column]==-1){
            printf("     %c", SVSB);
        }else if(board[line][column]==0){
            printf("  O  %c", SVSB);
        }else if(board[line][column]==1){
            printf("  X  %c", SVSB);
        }
    }
    printf("\n%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c\n", SBLC, SHSB, SHSB, SHSB, SHSB, SHSB, SHBB, SHSB, SHSB, SHSB, SHSB, SHSB, SHBB, SHSB, SHSB, SHSB, SHSB, SHSB, SHBB, SHSB, SHSB, SHSB, SHSB, SHSB, SHBB, SHSB, SHSB, SHSB, SHSB, SHSB, SHBB, SHSB, SHSB, SHSB, SHSB, SHSB, SHBB, SHSB, SHSB, SHSB, SHSB, SHSB, SHBB, SHSB, SHSB, SHSB, SHSB, SHSB, SHBB, SHSB, SHSB, SHSB, SHSB, SHSB, SHBB, SHSB, SHSB, SHSB, SHSB, SHSB, SBRC);
}

void startShips(int ships[][4]){
    srand(time(NULL));
    int ship, last;


    //Donnez les bateaux une location sur la grille
    for(ship=0 ; ship < 5 ; ship++){
        ships[ship][0]= rand()%9;
        ships[ship][1]= rand()%9;


        //Vérifions si ce coup n'a pas été essayé
        //si c'était le cas, sortez simplement de la boucle 'do while' quand vous tirez une paire qui n'a pas été essayée
        for(last=0 ; last < ship ; last++){
            if( (ships[ship][0] == ships[last][0])&&(ships[ship][1] == ships[last][1]) )
                do{
                    ships[ship][0]= rand()%9;
                    ships[ship][1]= rand()%9;
                } while( (ships[ship][0] == ships[last][0])&&(ships[ship][1] == ships[last][1]) );
        }

    }
}

void giveShot(int shot[2])
{

    printf("Ligne: ");
    scanf("%d",&shot[0]);
    shot[0]--;                                  //Ce partie prendre le location du tir
    printf("Colonne: ");
    scanf("%d",&shot[1]);
    shot[1]--;

}
//Ce partie est pour afficher un menu
void Start(){
    printf("\t\t\t\t\t%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c", STLC, SHSB, SHSB, SHSB, SHSB, SHSB, SHSB, SHSB, SHSB, SHSB, SHSB, SHSB, SHSB, SHSB, SHSB, SHSB, SHSB, SHSB, SHSB, SHSB, SHSB, SHSB, SHSB, SHSB, SHSB, SHSB, SHSB, SHSB, SHSB, STRC);
    printf("\n\t\t\t\t\t%c      BATAILLE NAVALE!      %c", SVSB, SVSB);
    printf("\n\t\t\t\t\t%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c\n", SBLC, SHSB, SHSB, SHSB, SHSB, SHSB, SHSB, SHSB, SHSB, SHSB, SHSB, SHSB, SHSB, SHSB, SHSB, SHSB, SHSB, SHSB, SHSB, SHSB, SHSB, SHSB, SHSB, SHSB, SHSB, SHSB, SHSB, SHSB, SHSB, SBRC);
}

void Choice(){
    printf("\n\t\t\t\t\t%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c", STLC, SHSB, SHSB, SHSB, SHSB, SHSB, SHSB, SHSB, SHSB, SHSB, SHSB, SHSB, SHSB, SHSB, SHSB, SHSB, SHSB, SHSB, SHSB, SHSB, SHSB, SHSB, SHSB, SHSB, SHSB, SHSB, SHSB, SHSB, SHSB, STRC);
    printf("\n\t\t\t\t\t%c          1) Jeu            %c", SVSB, SVSB);
    printf("\n\t\t\t\t\t%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c\n", SBLC, SHSB, SHSB, SHSB, SHSB, SHSB, SHSB, SHSB, SHSB, SHSB, SHSB, SHSB, SHSB, SHSB, SHSB, SHSB, SHSB, SHSB, SHSB, SHSB, SHSB, SHSB, SHSB, SHSB, SHSB, SHSB, SHSB, SHSB, SHSB, SBRC);
    printf("\t\t\t\t\t%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c", STLC, SHSB, SHSB, SHSB, SHSB, SHSB, SHSB, SHSB, SHSB, SHSB, SHSB, SHSB, SHSB, SHSB, SHSB, SHSB, SHSB, SHSB, SHSB, SHSB, SHSB, SHSB, SHSB, SHSB, SHSB, SHSB, SHSB, SHSB, SHSB, STRC);
    printf("\n\t\t\t\t\t%c         2) Scores          %c", SVSB, SVSB);
    printf("\n\t\t\t\t\t%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c\n", SBLC, SHSB, SHSB, SHSB, SHSB, SHSB, SHSB, SHSB, SHSB, SHSB, SHSB, SHSB, SHSB, SHSB, SHSB, SHSB, SHSB, SHSB, SHSB, SHSB, SHSB, SHSB, SHSB, SHSB, SHSB, SHSB, SHSB, SHSB, SHSB, SBRC);
    printf("\t\t\t\t\t%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c", STLC, SHSB, SHSB, SHSB, SHSB, SHSB, SHSB, SHSB, SHSB, SHSB, SHSB, SHSB, SHSB, SHSB, SHSB, SHSB, SHSB, SHSB, SHSB, SHSB, SHSB, SHSB, SHSB, SHSB, SHSB, SHSB, SHSB, SHSB, SHSB, STRC);
    printf("\n\t\t\t\t\t%c         3) Aide            %c", SVSB, SVSB);
    printf("\n\t\t\t\t\t%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c\n", SBLC, SHSB, SHSB, SHSB, SHSB, SHSB, SHSB, SHSB, SHSB, SHSB, SHSB, SHSB, SHSB, SHSB, SHSB, SHSB, SHSB, SHSB, SHSB, SHSB, SHSB, SHSB, SHSB, SHSB, SHSB, SHSB, SHSB, SHSB, SHSB, SBRC);
    printf("\t\t\t\t\tEntrez votre choix ici: ");
}

int hitship(int shot[2], int ships[][4])
{
    int ship;

    for(ship=0 ; ship < 5 ; ship++){
        if( shot[0]==ships[ship][0] && shot[1]==ships[ship][1]){
            printf("\nT'as frapper un bateau avec le tir (%d,%d)\n",shot[0]+1,shot[1]+1);   //Pour verifier si t'as touché un bateau
            return 1;
        }
    }
    return 0;
}

void tip(int shot[2], int ships[][4], int attempt)
{
    int line=0,
            column=0,
            row;

    //Combien des bateaux sont-ils dans le ligne/colonne
    for(row=0 ; row < 5 ; row++){
        if(ships[row][0]==shot[0])
            line++;
        if(ships[row][1]==shot[1])
            column++;
    }

    printf("\nTourne %d: \nLigne %d -> %d ships\nColonne %d -> %d ships\n",attempt,shot[0]+1,line,shot[1]+1,column);
}

void changeBoard(int shot[2], int ships[][4], int board[][9]){
    if(hitship(shot,ships))
        board[shot[0]][shot[1]]=1;
    else
        board[shot[0]][shot[1]]=0;
}

void aide(){


    //Petit message d'aide pour le jouer

    printf("\n\n\n\n\n\n\n\n\n\n\n\n\n\t\t\t\t\t\t\t%c%c%c%c%c%c%c%c\n", DTLC, DHSB, DHSB, DHSB, DHSB, DHSB, DHSB,DTRC);
    printf("\t\t\t\t\t\t\t%c AIDE %c\n", DVSB, DVSB);
    printf("\t\t\t\t\t\t\t%c%c%c%c%c%c%c%c\n\n\n", DBLC, DHSB, DHSB, DHSB, DHSB, DHSB, DHSB, DBRC);
    printf("\nLe but de ce programme est pour simuler une bataille navale, avec C. \nCe programme est une partie dans un projet pour notre classe ICT-431.\n"
           "\n"
           "Pour jouer, vous devez trouver les bateaux dans une grille, il y a 3 bateaux trouvez dans l'eau. Quand t'as trouver tous les bateaux, t'as gagner. Vous pouvez refaire pour ameliorer votre score, ou vous pouvez sauvegarder votre score\n\n");
}

int main() {
    int board[9][9];
    int ships[5][4];
    int shot[2];
    int attempts=0,
            hits=0;
    char username[20];
    int Highscore;
    char message;
    int choice;
        FILE *f;
        Start();
        printf("\t\t\t\t\tEntrez votre nom :");
        scanf("%s", &username);
        Choice();
        scanf("%d", &choice);
        system("Cls");
        if (choice == 1){
            startBoard(board);
            startShips(ships);

            printf("\n");

            do{
                showBoard(board);
                giveShot(shot);              //Pour tirer aux bateau
                attempts++;

                if(hitship(shot,ships)){
                    tip(shot,ships,attempts);       //Verifier si t'as frapper un bateau ou pas
                    hits++;
                }
                else
                    tip(shot,ships,attempts);
                printf("\nAttempts: %d", attempts);
                printf("\nHits: %d", hits);
                changeBoard(shot,ships,board);


            }while(hits!=5);
            printf("\n\n\nJeu fini. T'as frapper tous les bateaux dans %d attempts", attempts);  //Bien Joué, t'as gagné
            showBoard(board);
        }
        else if (choice == 2){
            f = fopen("highscore.txt", "r");
            rewind(f);
            while((message=fgetc(f))!=EOF) {        //Toute ça prendre les highscores dans highscore.txt
                printf("%c", message);
            }
            printf("\nSi c'est pas le score correcte, va au NEWBATNAV\\cmake-build-debug\\highscore.txt et changer votre score\n\n");
            fclose(f);
            system("Pause");
        }
        else if (choice == 3){
            aide();
            system("Pause");
        }
}